import { config } from 'dotenv';
config();

import '@/ai/flows/generate-opportunities.ts';
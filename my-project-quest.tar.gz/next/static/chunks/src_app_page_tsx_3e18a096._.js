(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_688903bc._.js",
  "static/chunks/node_modules_474fc747._.js"
],
    source: "dynamic"
});
